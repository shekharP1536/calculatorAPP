package com.nooneknow.carculator;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edit;
    TextView preview;
    boolean newOp = true;
    String op = "+";
    String oldNumber = "";
//    Button button7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit = findViewById(R.id.editTextText);
        preview = findViewById(R.id.preview);
//        button7 = findViewById(R.id.button7);


    }

    public void numberEvent(View view) {
        if(newOp){
            edit.setText("");
            newOp = false;
        }
        String number = edit.getText().toString();
        if (edit.getText().toString().length()>=8){
            edit.setTextSize(45);
        }else if (edit.getText().toString().length()>12){
            edit.setTextSize(32);
        }else if (edit.getText().toString().length()>=18){
            edit.setTextSize(22);
        }else {
            edit.setTextSize(60);
        }
        int button = view.getId();
        if (button == R.id.button7){
            number += "7";
        } else if (button == R.id.button8) {
            number +="8";
        } else if (button == R.id.button9) {
            number +="9";
        }else if (button == R.id.button4){
            number += "4";
        } else if (button == R.id.button5) {
            number += "5";
        } else if (button == R.id.button6) {
            number += "6";
        }else if (button == R.id.button1) {
            number += "1";
        }else if (button == R.id.button2) {
            number += "2";
        }else if (button == R.id.button3) {
            number += "3";
        }else if (button == R.id.zero) {
            number += "0";
        }else if (button == R.id.dot) {
            if (newOp){
                number = ".";
            }else if(!number.contains(".")) {
                number += ".";
            }
        }else if (button == R.id.divide) {
            number += "/";
        }else if (button == R.id.minus) {
            number += "-";
        }else if (button == R.id.plus) {
            number += "+";
        }else if (button == R.id.multiply) {
            number += "x";
        }else if (button == R.id.plusMinus) {
            if (number.contains("-")) {
                number = number.replaceAll("-", "");
            }else if (number.equals("0")) {
                number = "0";
            }else {
                number = "-"+number;
            }
        }
        edit.setText(number);
    }

    public void operatorEvent(View view) {
        if (edit.getText().toString().length()>=8){
            edit.setTextSize(45);
        }else {
            edit.setTextSize(60);
        }
        newOp = true;
        oldNumber = edit.getText().toString();
        int OP = view.getId();

        if (OP == R.id.divide){
            op = "/";
        } else if (OP == R.id.minus) {
            op = "-";
        } else if (OP == R.id.multiply) {
            op = "*";
        } else if (OP == R.id.plus) {
            op = "+";
        }
        preview.setText(oldNumber.concat(op));
    }

    public void equalEvent(View view) {
        if (edit.getText().toString().length()>=8){
            edit.setTextSize(45);
        }else {
            edit.setTextSize(60);
        }
        String newNumber = edit.getText().toString();
        double result = 0.0;
        switch (op){
            case "+":
                result = Double.parseDouble(oldNumber) + Double.parseDouble(newNumber);
                break;
            case "-":
                result = Double.parseDouble(oldNumber) - Double.parseDouble(newNumber);
                break;
            case "*":
                result = Double.parseDouble(oldNumber) * Double.parseDouble(newNumber);
                break;
            case "/":
                result = Double.parseDouble(oldNumber) / Double.parseDouble(newNumber);
                break;

        }
        edit.setText(String.format("%s", result));
        preview.setText(String.format("%s%s%s", oldNumber, op, newNumber));

    }

    public void clearEvent(View view) {
        
        edit.setText("0");
        preview.setText("");
        newOp  = true;
    }

    public void percentageEvent(View view) {
        if (edit.getText().toString().length()<=8){
            edit.setTextSize(45);
        }else {
            edit.setTextSize(60);
        }
        Double numberForPercentage = Double.parseDouble(edit.getText().toString());
        edit.setText(String.format("%s", numberForPercentage));
        newOp = true;
        preview.setText(String.format("%s/100", numberForPercentage));

    }

    public void squareEvent(View view) {
        if (edit.getText().toString().length()>=8){
            edit.setTextSize(45);
        }else {
            edit.setTextSize(60);
        }
        double squareNumber = Double.parseDouble(edit.getText().toString());
        String  squareRoot = String.valueOf(Math.sqrt(squareNumber));
        newOp = true;
        edit.setText(squareRoot);
        preview.setText(String.format("sqrt(%s)",squareNumber));
    }

    public void trignometryEvent(View view) {
        if (edit.getText().toString().length()>=8){
            edit.setTextSize(45);
        }else {
            edit.setTextSize(60);
        }
        int requiredNumber = view.getId();
        String number = edit.getText().toString();
        double newNumber = Double.parseDouble(number);
        String noNumber = String.valueOf(Math.toRadians(Double.parseDouble(number)));
        if (requiredNumber == R.id.sin){
           newNumber = Math.sin(Double.parseDouble(noNumber));
           edit.setText(String.format("%s",newNumber));
           preview.setText(String.format("sin(%s)", newNumber));
        } else if (requiredNumber == R.id.cos) {
            newNumber = Math.cos(Double.parseDouble(noNumber));
            edit.setText(String.format("%s",newNumber));
            preview.setText(String.format("sin(%s)", newNumber));
        }else if (requiredNumber == R.id.tan) {
            newNumber = Math.tan(Double.parseDouble(noNumber));
            edit.setText(String.format("%s",newNumber));
            preview.setText(String.format("sin(%s)", newNumber));
        }else if (requiredNumber == R.id.square) {
            edit.setText(String.format("%S",newNumber*newNumber));
            preview.setText(String.format("sqr(%s)",newNumber));
        }
    }
}